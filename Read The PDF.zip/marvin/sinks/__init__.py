from .stdout import StdoutSink
from .file import FileSink
from .http import HTTPSink
