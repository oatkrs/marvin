from .windows import WindowsEVTXCollector, WindowsRegistryCollector
from .linux import LinuxSyslogCollector, LinuxJournaldCollector
from .file import FileTailCollector
from .command import CommandCollector

